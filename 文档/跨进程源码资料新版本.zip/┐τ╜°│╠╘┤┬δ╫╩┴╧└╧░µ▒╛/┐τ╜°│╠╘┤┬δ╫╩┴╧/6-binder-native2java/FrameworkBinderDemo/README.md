课程使用是：server_c++作为native服务端
            ClientDemo作为java客户端
			同时这里还有一个ServerDemo,它是java的客户端，给大家扩展学习